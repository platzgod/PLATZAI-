from datetime import datetime
from typing import TypeVar

T = TypeVar('T', bound='Filetime')

class Filetime(datetime):
    @classmethod
    def from_msfiletime(cls, filetime: int) -> Filetime: ...
    def to_msfiletime(self) -> int: ...
