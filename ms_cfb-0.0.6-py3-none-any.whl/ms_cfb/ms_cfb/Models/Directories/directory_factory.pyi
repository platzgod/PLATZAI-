from ms_cfb.Models.Directories.directory import Directory as Directory
from ms_cfb.Models.Directories.root_directory import RootDirectory as RootDirectory
from ms_cfb.Models.Directories.storage_directory import StorageDirectory as StorageDirectory
from ms_cfb.Models.Directories.stream_directory import StreamDirectory as StreamDirectory
from typing import TypeVar

T = TypeVar('T', bound='DirectoryFactory')

class DirectoryFactory:
    @classmethod
    def from_binary(cls, data: bytes) -> Directory: ...
