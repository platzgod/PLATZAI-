from ms_cfb.Models.DataStreams.array_stream import ArrayStream as ArrayStream
from ms_cfb.Models.Directories.directory import Directory as Directory
from typing import TypeVar

T = TypeVar('T', bound='DirectoryStream')

class DirectoryStream(ArrayStream):
    def __init__(self) -> None: ...
    def stream_size(self) -> int: ...
