from ms_cfb.Models.DataStreams.array_stream import ArrayStream as ArrayStream
from ms_cfb.Models.DataStreams.file_stream import FileStream as FileStream
from typing import TypeVar

T = TypeVar('T', bound='FileArray')

class FileArray(ArrayStream): ...
