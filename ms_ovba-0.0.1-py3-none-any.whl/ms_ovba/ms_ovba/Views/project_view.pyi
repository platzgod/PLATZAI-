from _typeshed import Incomplete
from ms_ovba.vbaProject import VbaProject as VbaProject
from typing import TypeVar

T = TypeVar('T', bound='ProjectView')

class ProjectView:
    project: Incomplete
    def __init__(self, project: VbaProject, reserved: int = 3) -> None: ...
    def to_bytes(self) -> bytes: ...
    def write_file(self) -> None: ...
