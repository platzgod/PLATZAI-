from _typeshed import Incomplete
from ms_ovba.vbaProject import VbaProject as VbaProject
from typing import TypeVar

T = TypeVar('T', bound='ProjectLk')

class ProjectLk:
    project: Incomplete
    def __init__(self, project: VbaProject) -> None: ...
    def to_bytes(self) -> bytes: ...
    def write_file(self) -> None: ...
