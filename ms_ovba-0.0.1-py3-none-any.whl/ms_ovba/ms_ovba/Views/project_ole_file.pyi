from ms_ovba.Views.dirStream import DirStream as DirStream
from ms_ovba.Views.project import Project as Project
from ms_ovba.Views.projectWm import ProjectWm as ProjectWm
from ms_ovba.Views.project_view import ProjectView as ProjectView
from ms_ovba.vbaProject import VbaProject as VbaProject
from typing import TypeVar

T = TypeVar('T', bound='ProjectOleFile')

class ProjectOleFile:
    @staticmethod
    def write_file(project: VbaProject) -> None: ...
