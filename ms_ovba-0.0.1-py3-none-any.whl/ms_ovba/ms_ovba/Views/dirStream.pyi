from _typeshed import Incomplete
from ms_ovba.Models.Fields.doubleEncodedString import DoubleEncodedString as DoubleEncodedString
from ms_ovba.Models.Fields.idSizeField import IdSizeField as IdSizeField
from ms_ovba.Models.Fields.packed_data import PackedData as PackedData
from ms_ovba.vbaProject import VbaProject as VbaProject
from typing import TypeVar

T = TypeVar('T', bound='DirStream')
PackableData = DoubleEncodedString | IdSizeField | PackedData

class DirStream:
    def __init__(self, project: VbaProject) -> None: ...
    project_cookie: Incomplete
    def to_bytes(self) -> bytes: ...
    def include_compat(self) -> None: ...
    def write_file(self) -> None: ...
