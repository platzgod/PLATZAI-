from ms_ovba.Models.Entities.doc_module import DocModule as DocModule
from ms_ovba.Models.Entities.reference import Reference as Reference
from ms_ovba.Models.Entities.reference_registered import ReferenceRegistered as ReferenceRegistered
from ms_ovba.Models.Entities.std_module import StdModule as StdModule
from ms_ovba.Models.Fields.libid_reference import LibidReference as LibidReference
from ms_ovba.Views.project_ole_file import ProjectOleFile as ProjectOleFile
from ms_ovba.vbaProject import VbaProject as VbaProject

def main() -> None: ...
