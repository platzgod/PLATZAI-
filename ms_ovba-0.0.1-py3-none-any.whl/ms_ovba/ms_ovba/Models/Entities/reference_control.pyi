import uuid
from ms_ovba.Models.Entities.reference_record import ReferenceRecord as ReferenceRecord
from ms_ovba.Models.Fields.doubleEncodedString import DoubleEncodedString as DoubleEncodedString
from ms_ovba.Models.Fields.libid_reference import LibidReference as LibidReference
from typing import TypeVar

T = TypeVar('T', bound='ReferenceControl')

class ReferenceControl(ReferenceRecord):
    def __init__(self, ref: LibidReference, ref2: LibidReference, guid: uuid.UUID, cookie: int, name: str = '') -> None: ...
    def pack(self, endien: str, cp_name: str) -> bytes: ...
    @staticmethod
    def unpack(data: bytes, endien: str) -> ReferenceControl: ...
