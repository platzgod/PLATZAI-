from ms_ovba.Models.Entities.reference_record import ReferenceRecord as ReferenceRecord
from ms_ovba.Models.Fields.project_reference import ProjectReference as ProjectReference
from typing import TypeVar

T = TypeVar('T', bound='ReferenceProject')

class ReferenceProject(ReferenceRecord):
    def __init__(self, ref: ProjectReference) -> None: ...
    def pack(self, endien: str, cp_name: str) -> bytes: ...
