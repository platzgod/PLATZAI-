from typing import TypeVar

T = TypeVar('T', bound='PasswordHash')

class PasswordHash:
    def __init__(self, password: str) -> None: ...
    def to_bytes(self) -> bytes: ...
