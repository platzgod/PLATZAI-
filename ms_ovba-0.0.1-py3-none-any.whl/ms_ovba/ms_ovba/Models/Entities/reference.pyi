from ms_ovba.Models.Entities.reference_record import ReferenceRecord as ReferenceRecord
from ms_ovba.Models.Fields.doubleEncodedString import DoubleEncodedString as DoubleEncodedString
from typing import TypeVar

T = TypeVar('T', bound='Reference')

class Reference:
    def __init__(self, ref: ReferenceRecord, name: str = '') -> None: ...
    def pack(self, endien: str, cp_name: str) -> bytes: ...
    @staticmethod
    def unpack(data: bytes, endien: str) -> Reference: ...
