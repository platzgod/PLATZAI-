from ms_ovba.Models.Entities.module_base import ModuleBase as ModuleBase
from typing import TypeVar

T = TypeVar('T', bound='StdModule')

class StdModule(ModuleBase):
    type: str
    def __init__(self, name: str) -> None: ...
    def normalize_file(self) -> None: ...
