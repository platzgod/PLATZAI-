from ms_ovba.Models.Entities.reference_control import ReferenceControl as ReferenceControl
from ms_ovba.Models.Entities.reference_record import ReferenceRecord as ReferenceRecord
from ms_ovba.Models.Fields.libid_reference import LibidReference as LibidReference
from typing import TypeVar

T = TypeVar('T', bound='ReferenceOriginal')

class ReferenceOriginal(ReferenceRecord):
    def __init__(self, libid_ref: LibidReference, ref_cntl: ReferenceControl) -> None: ...
    def pack(self, endien: str, cp_name: str) -> bytes: ...
    @staticmethod
    def unpack(data: bytes, endien: str) -> ReferenceOriginal: ...
