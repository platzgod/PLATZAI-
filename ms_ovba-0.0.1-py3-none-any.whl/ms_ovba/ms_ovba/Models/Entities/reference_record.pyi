from typing import TypeVar

T = TypeVar('T', bound='ReferenceRecord')

class ReferenceRecord:
    def pack(self, endien: str, cp_name: str) -> bytes: ...
    @staticmethod
    def unpack(bytestring: bytes, endien: str) -> ReferenceRecord: ...
