import uuid
from typing import TypeVar

T = TypeVar('T', bound='LibidReference')

class LibidReference:
    def __init__(self, libid_guid: uuid.UUID, version: str, libid_lcid: str, libid_path: str = '', libid_reg_name: str = '', windows_path: bool | None = None) -> None: ...
    def __len__(self) -> int: ...
    @staticmethod
    def unpack(byte_data: bytes) -> LibidReference: ...
