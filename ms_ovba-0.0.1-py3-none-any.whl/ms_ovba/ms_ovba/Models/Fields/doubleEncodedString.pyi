from _typeshed import Incomplete
from ms_ovba.Models.Fields.idSizeField import IdSizeField as IdSizeField
from typing import TypeVar

T = TypeVar('T', bound='DoubleEncodedString')

class DoubleEncodedString:
    ids: Incomplete
    def __init__(self, ids: list, text: str) -> None: ...
    @property
    def value(self) -> str: ...
    mod_name1: Incomplete
    mod_name2: Incomplete
    def pack(self, endien: str, cp_name: str) -> bytes: ...
