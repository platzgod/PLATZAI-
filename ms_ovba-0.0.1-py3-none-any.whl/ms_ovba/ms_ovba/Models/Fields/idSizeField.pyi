from _typeshed import Incomplete
from typing import Any, TypeVar

T = TypeVar('T', bound='IdSizeField')

class IdSizeField:
    def __init__(self, id: int, size: int, value: Any) -> None: ...
    @property
    def value(self) -> Any: ...
    stringValue: Incomplete
    def pack(self, endien: str, cp_name: str | None = None) -> bytes: ...
