from _typeshed import Incomplete
from typing import Any, TypeVar

T = TypeVar('T', bound='PackedData')

class PackedData:
    values: Incomplete
    format: Incomplete
    def __init__(self, format: str, *values: Any) -> None: ...
    def pack(self, endien: str, cp_name: str | None = None) -> bytes: ...
